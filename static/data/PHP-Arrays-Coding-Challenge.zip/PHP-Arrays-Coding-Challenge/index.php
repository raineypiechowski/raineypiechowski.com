<!DOCTYPE html>
<html>
<head>
	<title>PHP Associative Arrays</title>
</head>
<body>
<p>Complete both problems. When you are done with problem 2 this page should display a table that looks like this:</p>
<img src="table.png" alt="table" width="250">
<?php

	/*
	PROBLEM 1
	Create variable named $users.
	This variable should store an array of associative arrays.
	Each associative array will have the following keys:
			firstName (string)
			lastName (string)
			age (number)
			active (boolean)

	Put the following information into the array...
	
	firstName		lastName		age 		active
	---------------------------------------------------
	Bob				Smith			27			false
	Betty			Jones			22			true
	Sally			Thompson		33			true
	*/

	$users = array();
	$users[] = array("firstName" => "Bob", "lastName" => "Smith", "age" => 27, "active" => false);
	$users[] = array("firstName" => "Betty", "lastName" => "Jones", "age" => 22, "active" => true);
	$users[] = array("firstName" => "Sally", "lastName" => "Thompson", "age" => 33, "active" => true);

	/*
	Problem 2
	Write a function named createTable.
	The function should have a parameter, which is an array of users (just like the one you created above).
	The function should return a string that represents an HTML table element.
	If you echo this string, the table should look like the image on this page.
	Note that if a user is 'active', then the checkbox input in the last column should be checked.
	
	When you finish writing the code for the function, invoke it an pass in the $users array from problem 1.
	Make sure to echo the returned HTML string.
	*/

	function create_table($users) {
		$html = '<table border="1"><thead><tr><th>First Name</th><th>Last Name</th><th>Age</th><th>Active</th>';
		$html .= '</tr></thead>';

		foreach ($users as $user) {
			$html .= "<tr><td>{$user["firstName"]}</td><td>{$user["lastName"]}</td><td>{$user["age"]}</td>";

			$html .= '<td><input type="checkbox"';
			if ($user["active"]) {
				$html .= " checked";
			}
			$html .= '></td><tr>';
		}

		$html .= '</table>';

		return $html;
	}

	echo("<h1>Users</h1>");
	echo(create_table($users));
?>

</body>
</html>